//
//  BaseViewController.h
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/26.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@property (nonatomic, assign) CGFloat g_OffsetY;
@property (nonatomic, strong) UIButton *rightButton;

- (UIButton *)setLeftButton:(UIImage *)image title:(NSString *)title target:(id)target action:(SEL)selector;

- (UIButton *)setLeftButton:(UIImage *)image title:(NSString *)title target:(id)target action:(SEL)selector rect:(CGRect)rect;

- (UIButton *)setRightButton:(UIImage *)image title:(NSString *)title target:(id)target action:(SEL)selector;

- (UIButton *)setRightButton:(UIImage *)image title:(NSString *)title target:(id)target action:(SEL)selector rect:(CGRect)rect;

@end
