//
//  BaseViewController.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/26.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "BaseViewController.h"
#import "UIView+RSAdditions.h"



@interface BaseViewController (){
    UIButton *_currentButton;
}

@end

@implementation BaseViewController
@synthesize g_OffsetY;
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.translucent = NO;
    
    //去除导航栏下方的横线
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new]
                                                 forBarPosition:UIBarPositionAny
                                                     barMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
}
- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.view.backgroundColor = RGBcolor(255, 255, 255);
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    //统一设置输入框的样式
    [UITextView appearance].textContainerInset = UIEdgeInsetsMake(10, 10, 10, 10);
    
    if (self != [self.navigationController.viewControllers objectAtIndex:0]) {
        UIBarButtonItem *barItem= [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"iconfont-fanhui"] style:UIBarButtonItemStylePlain target:self action:@selector(back)];
        self.navigationItem.leftBarButtonItem =barItem;
    }
    if (self.navigationItem!=nil || self != [self.navigationController.viewControllers objectAtIndex:0]) {
        [self.navigationController.navigationBar setBarTintColor:BG_Color];
        self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
    }
}

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (UIButton *)setRightButton:(UIImage *)image title:(NSString *)title target:(id)target action:(SEL)selector{
    UIButton *currentButton = [self setRightButton:image title:title target:target action:selector rect:CGRectNull];
    return currentButton;
}

- (UIButton *)setRightButton:(UIImage *)image title:(NSString *)title target:(id)target action:(SEL)selector rect:(CGRect)rect{
    if (self.navigationController && self.navigationItem) {
        CGRect buttonFrame;
        CGRect viewFrame;
        if (CGRectIsNull(rect)) {
            buttonFrame = CGRectMake(0, 0, 44, 44);
            viewFrame = CGRectMake(0, 0, 44, 44);
        } else {
            buttonFrame = rect;
            viewFrame = rect;
        }
        UIButton *button = [[UIButton alloc] initWithFrame:buttonFrame];
        if (image) {
            UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
            imageView.center = CGPointMake(button.width / 2, button.height / 2);
            imageView.bounds = CGRectMake(0, 0, 16, 16);
            [button addSubview:imageView];
        }
        if (title) {
            [button setTitle:title forState:UIControlStateNormal];
            button.titleLabel.font = [UIFont systemFontOfSize:16.0];
            //Customzied TitleColor..
            [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        }
        [button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
        UIView *view = [[UIView alloc] initWithFrame:viewFrame];
        [view addSubview:button];
        _currentButton = button;
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:view];
    }
    return _currentButton;
}

- (UIButton *)setLeftButton:(UIImage *)image title:(NSString *)title target:(id)target action:(SEL)selector{
    UIButton *currentButton = [self setLeftButton:image title:title target:target action:selector rect:CGRectNull];
    return currentButton;
}

- (UIButton *)setLeftButton:(UIImage *)image title:(NSString *)title target:(id)target action:(SEL)selector rect:(CGRect) rect{
    if (self.navigationItem && self.navigationController) {
        
        CGRect buttonFrame;
        CGRect viewFrame;
        if (CGRectIsNull(rect)) {
            buttonFrame = CGRectMake(0, 0, 44, 44);
            viewFrame = CGRectMake(0, 0, 44, 44);
        } else {
            buttonFrame = rect;
            viewFrame = rect;
        }
        
        UIButton *button = [[UIButton alloc] initWithFrame:buttonFrame];
        UIView *view = [[UIView alloc] initWithFrame:viewFrame];
        
        if (image) {
            UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
            imageView.center = CGPointMake(button.width / 2, button.height / 2);
            imageView.bounds = CGRectMake(0, 0, 20, 16);
            [button addSubview:imageView];
        }
        if (title) {
            [button setTitle:title forState:UIControlStateNormal];
            button.titleLabel.font = [UIFont systemFontOfSize:16.0];
            //Customzied TitleColor..
            [button setTitleColor:RGBcolor(30, 30, 30) forState:UIControlStateNormal];
        }
        [button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:button];
        _currentButton = button;
        
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:view];
    }
    return _currentButton;
}

@end
