//
//  HPProfileViewController.m
//  智慧社区
//
//  Created by 夏韩平 on 16/4/17.
//  Copyright © 2016年 Hoper. All rights reserved.
//

#import "MeViewController.h"

@interface MeViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UILabel *personalNameLabel;
@property (weak, nonatomic) IBOutlet UITableView *functionTableView;

@end

@implementation MeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"个人中心";
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section==0) {
        return 3;
    } else if (section==1) {
        return 1;
    } else {
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"function"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"function"];
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        if (indexPath.section==0) {
            if (indexPath.row==0) {
                cell.textLabel.text = @"收藏的预约点";
            } else if (indexPath.row==1) {
                cell.textLabel.text = @"评价";
            } else if (indexPath.row==2) {
                cell.textLabel.text = @"个性签名";
            }
        } else if (indexPath.section==1){
            cell.textLabel.text = @"设置";
        }
    }

//        HPProfileViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"function"];
//        
//        if (indexPath.row==0) {
//            cell.titleLabel.text = @"我的预约";
//        } else if (indexPath.row==1) {
//            cell.titleLabel.text = @"收藏的预约点";
//        } else if (indexPath.row==2) {
//            cell.titleLabel.text = @"消息";
//        }
        return cell;

}





@end
