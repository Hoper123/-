//
//  MessageViewController.h
//  ZHSQ_iOS
//
//  Created by 夏韩平 on 16/5/8.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "BaseViewController.h"

@interface MessageViewController : BaseViewController

@end
