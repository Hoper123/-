//
//  MessageViewController.m
//  ZHSQ_iOS
//
//  Created by 夏韩平 on 16/5/8.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "MessageViewController.h"
#import "MessageViewCell.h"
#import "PushViewController.h"
#import "AppointViewController.h"

@interface MessageViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation MessageViewController

static NSString *const MessageID = @"category";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([MessageViewCell class]) bundle:nil] forCellReuseIdentifier:MessageID];
    
    self.tableView.rowHeight = 50;
    
    self.title = @"消息";
    self.view.backgroundColor = [UIColor greenColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MessageViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MessageID];
    
    cell.iconImageView.image = [UIImage imageNamed:@"me"];
    
    if(indexPath.row % 2){
        cell.nameLabel.text = @"预约";
        cell.contentLebel.text = [NSString stringWithFormat:@"您已经预约成功"];
    } else {
        cell.nameLabel.text = @"推送";
        cell.contentLebel.text = [NSString stringWithFormat:@"系统向您推送了一条消息"];
    }
    cell.selectionStyle = NO;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 根据模型数据判断是哪种类型的消息
    if (indexPath.row % 2) {
        AppointViewController *appoint = [[AppointViewController alloc] init];
        MessageViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        cell.badgeImageView.hidden = YES;
        [self.navigationController pushViewController:appoint animated:YES];
    } else {
        PushViewController *push = [[PushViewController alloc] init];
        MessageViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        cell.badgeImageView.hidden = YES;
        [self.navigationController pushViewController:push animated:YES];
    }
    
}


@end
