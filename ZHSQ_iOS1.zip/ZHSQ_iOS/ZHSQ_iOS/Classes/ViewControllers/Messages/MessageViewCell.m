//
//  MessageViewCell.m
//  ZHSQ_iOS
//
//  Created by 夏韩平 on 16/5/8.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "MessageViewCell.h"


@implementation MessageViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



@end
