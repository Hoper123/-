//
//  AppointViewController.m
//  ZHSQ_iOS
//
//  Created by 夏韩平 on 16/5/9.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "AppointViewController.h"

@interface AppointViewController ()

@end

@implementation AppointViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"预约详情";
}


@end
