//
//  FunctionModel.h
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/26.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FunctionModel : NSObject

@property (copy, nonatomic) NSString* customUrl;

@property (copy, nonatomic) NSString* icon;

@property (copy, nonatomic) NSString* ID;

@property (copy, nonatomic) NSString* title;

@property (copy, nonatomic) NSString* url;

//写一个快速创建对象的方法

+ (instancetype)functionModelWithDict:(NSDictionary *)dict;


@end
