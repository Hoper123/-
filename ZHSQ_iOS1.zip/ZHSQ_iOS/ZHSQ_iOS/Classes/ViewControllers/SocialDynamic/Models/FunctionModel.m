//
//  FunctionModel.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/26.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "FunctionModel.h"

@implementation FunctionModel

+ (instancetype)functionModelWithDict:(NSDictionary *)dict {
    FunctionModel* model = [[FunctionModel alloc] init];
    //[product setValuesForKeysWithDictionary:dict];
    model.customUrl = dict[@"customUrl"];
    model.icon = dict[@"icon"];
    model.ID = dict[@"id"];
    model.title = dict[@"title"];
    model.url = dict[@"url"];
    return model;
}

//去除字符串“@2x.png”
- (void)setIcon:(NSString *)icon {
    _icon = [icon stringByReplacingOccurrencesOfString:@"@2x.png" withString:@""];
}


@end
