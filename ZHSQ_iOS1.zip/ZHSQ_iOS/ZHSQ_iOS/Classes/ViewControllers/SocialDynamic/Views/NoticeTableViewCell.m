//
//  NoticeTableViewCell.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/27.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "NoticeTableViewCell.h"

@implementation NoticeTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.imgView.layer.cornerRadius = 5.0;
    self.imgView.layer.masksToBounds = YES;
}

+ (instancetype)cellWithTableViewCell:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath isNoImage:(BOOL)isNoImage {
    NoticeTableViewCell* cell;
    if (!isNoImage) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"noticeTableViewCell"];
    } else {
        cell = [tableView dequeueReusableCellWithIdentifier:@"noImageNoticeTableViewCell"];
    }
    if (!cell) {
        if (!isNoImage) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"NoticeTableViewCell" owner:nil options:nil] lastObject];
        } else {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"NoImageNoticeTableViewCell" owner:nil options:nil] lastObject];
        }
    }
    return cell;

}

@end
