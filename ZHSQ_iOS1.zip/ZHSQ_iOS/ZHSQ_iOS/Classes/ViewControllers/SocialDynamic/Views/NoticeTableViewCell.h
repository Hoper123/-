//
//  NoticeTableViewCell.h
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/27.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoticeTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *TextLabel;

@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

+ (instancetype)cellWithTableViewCell:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath isNoImage:(BOOL)isNoImage;

@end
