//
//  FunctionModelCell.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/26.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "FunctionModelCell.h"
#import "FunctionModel.h"
@interface FunctionModelCell ()

@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;



@end;
@implementation FunctionModelCell


- (void)awakeFromNib {
    [super awakeFromNib];
    self.imgView.layer.cornerRadius = self.imgView.frame.size.height*0.5;
    self.imgView.layer.masksToBounds = YES;
}

-(void)setFunction:(FunctionModel *)function {
    _function = function;
    self.imgView.image = [UIImage imageNamed:function.icon];
    self.titleLabel.text = function.title;
}

@end
