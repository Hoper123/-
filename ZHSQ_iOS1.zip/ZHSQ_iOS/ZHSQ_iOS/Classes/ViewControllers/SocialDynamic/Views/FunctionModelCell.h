//
//  FunctionModelCell.h
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/26.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FunctionModel;
@interface FunctionModelCell : UICollectionViewCell
@property (nonatomic, strong) FunctionModel* function;

@end
