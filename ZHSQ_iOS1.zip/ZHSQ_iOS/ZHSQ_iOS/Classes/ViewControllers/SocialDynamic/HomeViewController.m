//
//  HomeViewController.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/26.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "HomeViewController.h"
#import "KDCycleBannerView.h"
#import "FunctionModel.h"
#import "FunctionModelCell.h"
#import "NoticeTableViewCell.h"

#define NAVGATIONBAR_HEIGHT 64
#define TABBAR_HEIGHT 49



@interface HomeViewController ()<KDCycleBannerViewDataSource, KDCycleBannerViewDelegate, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) UITableView *tableView;//整个首页容器
@property (nonatomic, strong) UISearchBar* searchBar;//搜索条
@property (nonatomic, strong) KDCycleBannerView *bannerView;//轮播图
@property (nonatomic, strong) UICollectionView *functionView;//轮播图
@property (nonatomic, strong) UITableView* noticeTableView;  //社区动态新闻


@property (nonatomic, strong) NSMutableArray* functions;  //存储模型


@end

@implementation HomeViewController

#pragma mark - 懒加载
/**
 *  搜索条
 */
- (UISearchBar *)searchBar {
    if (!_searchBar) {
        _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, kMainScreenWidth - 100, 30)];
        _searchBar.delegate = self;
        _searchBar.placeholder = @"输入社区新闻，动态";
        _searchBar.showsCancelButton = NO;
    }
    return _searchBar;
}

/**
 *  首页容器
 */
- (UITableView *)tableView {
    if (!_tableView) {
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, kMainScreenWidth, kMainScreenHeight-NAVGATIONBAR_HEIGHT-TABBAR_HEIGHT) style:UITableViewStyleGrouped];
        _tableView.backgroundColor = [UIColor whiteColor];
        //设置tableview的headerView
        UIView* headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kMainScreenWidth, self.bannerView.frame.size.height+ self.functionView.frame.size.height)];
        [headerView setBackgroundColor:[UIColor whiteColor]];
        [headerView addSubview:self.bannerView];
        [headerView addSubview:self.functionView];
        //设置代理
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
        _tableView.tableHeaderView = headerView;
    }
    return _tableView;
}

/**
 *  轮播图
 */
- (KDCycleBannerView *)bannerView {
    if (!_bannerView) {
        _bannerView = [[KDCycleBannerView alloc] initWithFrame:CGRectMake(0, 0, kMainScreenWidth, 0.2 * kMainScreenHeight)];
        _bannerView.datasource = self;
        _bannerView.delegate = self;
        _bannerView.continuous = YES;
        _bannerView.autoPlayTimeInterval = 6.0f;
    }
    return _bannerView;
}

/**
 *  功能模块图
    使用UICollectionView
    1. 必须布局
    2.cell自己注册
 */
- (UICollectionView *)functionView {
    if (!_functionView) {
        //流水布局
        UICollectionViewFlowLayout* layout = [[UICollectionViewFlowLayout alloc] init];

        _functionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0.2*kMainScreenHeight, kMainScreenWidth, 0.3*kMainScreenHeight) collectionViewLayout:layout];
        _functionView.backgroundColor = [UIColor whiteColor];
        layout.itemSize = CGSizeMake(kMainScreenWidth/4.0, kMainScreenWidth/4.0);
        layout.minimumInteritemSpacing = 0;
        layout.minimumLineSpacing = 0;
        layout.sectionInset = UIEdgeInsetsMake(20, 0, 0, 0);
        
        //设置代理
        _functionView.delegate = self;
        _functionView.dataSource = self;

    }
    return _functionView;
}

- (NSMutableArray *)functions {
    if (!_functions) {
        _functions = [NSMutableArray array];
        //3.得到路径
        NSString* fileName = [[NSBundle mainBundle] pathForResource:@"functionView.json" ofType:nil];
        
        //2.添加NSData
        NSData* data = [NSData dataWithContentsOfFile:fileName];
        
        //1.解析json,使用NSJSONSerialization，得到字典数组
        NSArray* jsonArray = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        //NSLog(@"%@", jsonArray);
        //4.字典数组转模型数组
        for (NSDictionary* dict in jsonArray) {
            FunctionModel* function = [FunctionModel functionModelWithDict:dict];
            [_functions addObject:function];
        }
    }
    return _functions;
}

/**
 *  动态新闻
 */
- (UITableView *)noticeTableView {
    if (!_noticeTableView) {
        _noticeTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, kMainScreenWidth, 470) style:UITableViewStyleGrouped];
        _noticeTableView.backgroundColor = [UIColor whiteColor];
        _noticeTableView.scrollEnabled = NO;
        _noticeTableView.showsHorizontalScrollIndicator = NO;
        _noticeTableView.showsVerticalScrollIndicator = NO;
        //设置代理
        _noticeTableView.dataSource = self;
        _noticeTableView.delegate = self;
        
        UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kMainScreenWidth, 30)];
        header.backgroundColor = [UIColor whiteColor];
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 80, 30)];
        titleLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:13];
        titleLabel.textColor = [UIColor darkGrayColor];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.text = @"社区动态";
        [header addSubview:titleLabel];
        _noticeTableView.tableHeaderView = header;
        
        UIView *footer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kMainScreenWidth, 40)];
        footer.backgroundColor = [UIColor whiteColor];
        
        UIButton *changeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [changeBtn setFrame:CGRectMake(0, 0, kMainScreenWidth / 2, 40.0f)];
        [changeBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
        [changeBtn setTitle:@"换一批" forState:UIControlStateNormal];
        changeBtn.titleLabel.font = [UIFont systemFontOfSize:16.0];
        [changeBtn addTarget:self action:@selector(changeNotices:) forControlEvents:UIControlEventTouchUpInside];
        [footer addSubview:changeBtn];
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(kMainScreenWidth/2, 5, 1.0, 30)];
        [line setBackgroundColor:[UIColor groupTableViewBackgroundColor]];
        [footer addSubview:line];
        
        UIButton *lookMoreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [lookMoreBtn setFrame:CGRectMake(kMainScreenWidth / 2, 0, kMainScreenWidth / 2, 40.0f)];
        [lookMoreBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
        [lookMoreBtn setTitle:@"更多资讯" forState:UIControlStateNormal];
        lookMoreBtn.titleLabel.font = [UIFont systemFontOfSize:16.0];
        [lookMoreBtn addTarget:self action:@selector(lookMoreNotices:) forControlEvents:UIControlEventTouchUpInside];
        [footer addSubview:lookMoreBtn];
        _noticeTableView.tableFooterView = footer;

        
    }
    return _noticeTableView;
}


#pragma mark - 加载视图
static NSString* const collectID = @"collect";
- (void)viewDidLoad {
    [super viewDidLoad];
    //通过xib注册
    UINib* functionXib = [UINib nibWithNibName:@"FunctionModelCell" bundle:nil];
    [self.functionView registerNib:functionXib forCellWithReuseIdentifier:collectID];
    
    self.view.backgroundColor = [UIColor purpleColor];
    [self setUI];
    
}

#pragma mark - 设置UI
- (void)setUI {
    //设置搜索框,在navigationItem中
    UIBarButtonItem* searchItem = [[UIBarButtonItem alloc] initWithCustomView:self.searchBar];
    self.navigationItem.rightBarButtonItem = searchItem;
    [self setLeftButton:nil title:@"杭州" target:self action:@selector(selectAddress)];
    
    [self.view addSubview:self.tableView];
}

- (void)selectAddress {
    NSLog(@"杭州");
}

#pragma mark - KDCycleBannerViewDataSource
- (NSArray *)numberOfKDCycleBannerView:(KDCycleBannerView *)bannerView {
    NSArray *temp = @[[UIImage imageNamed:@"timg1"],[UIImage imageNamed:@"timg2"], [UIImage imageNamed:@"timg3"]];
    return temp;
}

- (UIViewContentMode)contentModeForImageIndex:(NSUInteger)index {
    return UIViewContentModeScaleToFill;
}

#pragma mark - UICollectionView的dataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.functions.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    //1.创建UICollectionViewCell
    //forIndexPath表明从storyboard中取得
    FunctionModelCell* cell = [collectionView dequeueReusableCellWithReuseIdentifier:collectID forIndexPath:indexPath];
    
    //cell.backgroundColor = [UIColor redColor];
    
    //2.创建模型
    FunctionModel* function = self.functions[indexPath.item];
    //自定义cell
    cell.function = function;
    return cell;
}

#pragma mark - UICollectionView的delegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    //通过模型管理
    FunctionModel* function = self.functions[indexPath.item];
    NSLog(@"点击了----%@", function.title);
}

#pragma mark - UITableView的dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView == self.tableView) {
        return 1;
    }else if (tableView == self.noticeTableView) {
        return 1;
    }else {
        return 1;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == self.tableView) {
        return 1;
    } else if (tableView == self.noticeTableView) {
        return 5;
    } else {
        return 1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == self.tableView) {
        UITableViewCell *cell = [[UITableViewCell alloc] initWithFrame:CGRectMake(0, 0, kMainScreenWidth, 470)];
        [cell addSubview:self.noticeTableView];
        return cell;
    }else if (tableView == _noticeTableView) {
        NoticeTableViewCell *cell;
        if (indexPath.row != 3 && indexPath.row != 1) {
            cell = [NoticeTableViewCell cellWithTableViewCell:tableView indexPath:indexPath isNoImage:NO];
            
        } else {
            cell = [NoticeTableViewCell cellWithTableViewCell:tableView indexPath:indexPath isNoImage:YES];
        }
        return cell;
    } else { //无数据
        return nil;
    }
    
}

#pragma mark - UITableView的delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == _tableView) {
        return 470.0f;
    } else if (tableView == _noticeTableView) {
        return 80.0f;
    } else {
        return 30.0f;
    }
}



- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (tableView == _tableView) {
        return 10.0f;
    } else {
        return 0.01f;
    }
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01f;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *sectionHeader = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kMainScreenWidth, 10.0f)];
    [sectionHeader setBackgroundColor:[UIColor groupTableViewBackgroundColor]];
    return sectionHeader;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - 点击换一批
- (void)changeNotices:(UIButton *)sender {
    //换一批资讯
    [self.noticeTableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationLeft];
}



- (void)lookMoreNotices:(UIButton *)sender {
    //更多校园资讯
}



@end


