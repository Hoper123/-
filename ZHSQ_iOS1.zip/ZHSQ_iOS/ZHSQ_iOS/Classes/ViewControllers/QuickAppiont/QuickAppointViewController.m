//
//  QuickAppointViewController.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/26.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "QuickAppointViewController.h"
#import "MainButton.h"
#import "AFNetworking.h"

@interface QuickAppointViewController ()

@property (nonatomic, strong) MainButton* quickAppointBtn;  //一键预约按钮

@end

@implementation QuickAppointViewController
#pragma mark - 懒加载

- (MainButton *)quickAppointBtn {
    if (!_quickAppointBtn) {
        //设置frame
        _quickAppointBtn = [MainButton buttonWithType:UIButtonTypeCustom];
        [_quickAppointBtn setFrame:CGRectMake(0, 0, kMainScreenWidth*0.6, kMainScreenWidth*0.6)];
        _quickAppointBtn.center = self.view.center;
        
        _quickAppointBtn.backgroundColor =[UIColor blueColor];
        [_quickAppointBtn setTitle:@"一键预约" forState:UIControlStateNormal];
        [_quickAppointBtn setBackgroundImage:[UIImage imageNamed:@"QuickAppiont"] forState:UIControlStateNormal];
        [_quickAppointBtn setTintColor:[UIColor whiteColor]];
        [_quickAppointBtn addTarget:self action:@selector(quickAppointClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.view addSubview:_quickAppointBtn];
    }
    return _quickAppointBtn;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"一键预约";
    self.quickAppointBtn.hidden = NO;
    self.view.backgroundColor = [UIColor redColor];
}

#pragma mark - 一键预约按钮
- (void)quickAppointClick:(UIButton *)button {
    NSLog(@"%s111111111111", __func__);
    
    [[AFHTTPSessionManager manager] POST:@"192.168.1.107:8080/icis/app/aKeyAppoint" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"%@",responseObject);
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@",error);
    }];
    
    
    if (_quickAppointBtn.isSetDisplay == NO) {
        _quickAppointBtn.isSetDisplay = YES;
        [_quickAppointBtn setNeedsDisplay];
    }else {
        //如果_quickAppointBtn.isSetDisplay = YES;点击则为取消
        [_quickAppointBtn setTitle:@"取消" forState:UIControlStateNormal];
        return;
    }
}

@end
