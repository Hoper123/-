//
//  MainButton.h
//  ZHSQ_iOS
//
//  Created by KFallen on 16/5/8.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainButton : UIButton

@property (nonatomic, assign) BOOL isSetDisplay;  //是否重绘  YES是，NO不重绘
@end
