//
//  LoginViewController.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/24.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "LoginViewController.h"
#import "MBProgressHUD+NJ.h"
#import "RootTabBarController.h"
#import "AFNetworking.h"


@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *phoneNum;
@property (weak, nonatomic) IBOutlet UITextField *pwd;

@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UIButton *registerBtn;

- (IBAction)login:(UIButton *)sender;
- (IBAction)Register:(UIButton *)sender;
- (IBAction)forgotPwd:(UIButton *)sender;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUI];
}

/**
 *  设置UI界面
 */
- (void)setUI {
    self.phoneNum.layer.cornerRadius = 10.0f;
    self.phoneNum.layer.masksToBounds = YES;
    
    self.pwd.layer.cornerRadius = 10.0f;
    self.pwd.layer.masksToBounds = YES;
    
    self.loginBtn.layer.cornerRadius = 10.0f;
    self.loginBtn.layer.masksToBounds = YES;
    
    self.registerBtn.layer.cornerRadius = 10.0f;
    self.registerBtn.layer.masksToBounds = YES;
    
}

- (IBAction)login:(UIButton *)sender {
    RootTabBarController *rootTab = [[RootTabBarController alloc] init];
    
    rootTab.modalPresentationStyle = UIModalPresentationFullScreen;
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"username"] = self.phoneNum.text;
    params[@"password"] = self.pwd.text;
    
    [MBProgressHUD showMessage:@"正在登录..."];
    [[AFHTTPSessionManager manager] POST:@"http://192.168.1.107:8080/icis/app/doLogin" parameters:params success:^(NSURLSessionDataTask *task, id responseObject) {
        [MBProgressHUD hideHUD];
        
        [self loginAddPresentAnimation:rootTab];
        [self presentViewController:rootTab animated:NO completion:nil];
        NSLog(@"%@",responseObject);
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [MBProgressHUD hideHUD];
        NSLog(@"%@",error);
    }];

    //判断手机号
//    if (self.phoneNum.text.length == 0) {
//        [MBProgressHUD showError:@"请输入手机号"];
//        return;
//    };
//    //判断密码
//    if (self.pwd.text.length == 0) {
//        [MBProgressHUD showError:@"请输入密码"];
//        return;
//    };
//    //都有则判断正误
//    if (![self.phoneNum.text isEqualToString:@"123"]) {
//        [MBProgressHUD showError:@"该账户不存在"];
//        return;
//    } else {
//        if (![self.pwd.text isEqualToString:@"123"]) {
//            [MBProgressHUD showError:@"密码不正确"];
//            return;
//        } else { //正确
//            [self loginAddPresentAnimation:rootTab];
//            [self presentViewController:rootTab animated:NO completion:^{
//                
//            }];
//        }
//    }
}

/**
 *  成功登陆的动画
 *
 */
- (void)loginAddPresentAnimation:(RootTabBarController *)root {
    CATransition *animation = [CATransition animation];
    animation.duration = 1.0;
    animation.timingFunction = UIViewAnimationCurveEaseInOut;
    animation.type = @"rippleEffect";
    animation.subtype = kCATransitionFromBottom;
    self.view.window.layer.backgroundColor = [UIColor whiteColor].CGColor;
    root.view.window.layer.backgroundColor = [UIColor whiteColor].CGColor;
    [self.view.window.layer addAnimation:animation forKey:@"loginAnimation"];
}


- (IBAction)Register:(id)sender {
    
}

- (IBAction)forgotPwd:(UIButton *)sender {
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}
@end
