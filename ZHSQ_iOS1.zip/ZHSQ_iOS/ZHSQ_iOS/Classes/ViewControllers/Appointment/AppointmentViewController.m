//
//  AppointmentViewController.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/26.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "AppointmentViewController.h"
//#import "HPAppointmentInfoViewController.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface AppointmentViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *staffTableView; 
@property (weak, nonatomic) IBOutlet MKMapView *mapView;

/** lM */
@property (nonatomic, strong) CLLocationManager *lM;

@end

@implementation AppointmentViewController

- (CLLocationManager *)lM
{
    if (_lM == nil) {
        _lM = [[CLLocationManager alloc] init];
        if ([_lM respondsToSelector:@selector(requestAlwaysAuthorization)]) {
            //[_lM requestAlwaysAuthorization];
            [_lM requestWhenInUseAuthorization];
        }
    }
    return _lM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"社工预约";
    [self lM];
    // 显示当前位置
    self.mapView.showsUserLocation = YES;
    self.mapView.userTrackingMode = MKUserTrackingModeFollowWithHeading;
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    //    [self.staffTableView registerNib:[UINib nibWithNibName:@"UITableViewCell" bundle:nil] forCellReuseIdentifier:@"staff"];
    
    self.staffTableView.delegate = self;
    self.staffTableView.dataSource = self;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    /**
     MKMapTypeStandard = 0,
     MKMapTypeSatellite,
     MKMapTypeHybrid,
     MKMapTypeSatelliteFlyover NS_ENUM_AVAILABLE(10_11, 9_0),
     MKMapTypeHybridFlyover NS_ENUM_AVAILABLE(10_11, 9_0),
     */
    //    self.mapView.mapType = MKMapTypeSatelliteFlyover;
    
    //    self.mapView.zoomEnabled = NO;
    
    //    self.mapView.showsCompass = NO;
    //    self.mapView.showsScale = YES;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"staff"];
    
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"staff"];
    }
    cell.imageView.image = [UIImage imageNamed:@"me"];
    cell.imageView.layer.cornerRadius = 10;
    cell.imageView.layer.masksToBounds = YES;
    cell.textLabel.text = [NSString stringWithFormat:@"大学生社工"];
    cell.detailTextLabel.textColor = [UIColor lightGrayColor];
    cell.detailTextLabel.text = @"tooyoung,toosimple";
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    AppointmentViewController *appointmentInfo = [[AppointmentInfoViewController alloc] init];
//    appointmentInfo.name = [NSString stringWithFormat:@"%zd",indexPath.row + 1];
//    [self.navigationController pushViewController:appointmentInfo animated:YES];
}

@end
