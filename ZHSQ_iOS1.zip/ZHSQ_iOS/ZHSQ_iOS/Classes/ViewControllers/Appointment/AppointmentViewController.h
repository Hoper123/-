//
//  AppointmentViewController.h
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/27.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "BaseViewController.h"

@interface AppointmentViewController : BaseViewController

@end
