//
//  TabBarButton.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/5/7.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "TabBarButton.h"

@implementation TabBarButton

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        //
    }
    return self;
}


- (void)layoutSubviews {
    
}

@end
