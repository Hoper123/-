//
//  RootNavigationController.h
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/26.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootNavigationController : UINavigationController

- (void)setTabBarTitle:(NSString *)title image:(NSString *)imageName selectedImage:(NSString *)selectImageName;

@end
