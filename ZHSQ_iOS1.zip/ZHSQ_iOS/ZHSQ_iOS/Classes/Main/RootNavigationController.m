//
//  RootNavigationController.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/26.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "RootNavigationController.h"

@interface RootNavigationController ()

@end

@implementation RootNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}


+ (void)initialize {
    //设置导航条背景颜色
    [[UINavigationBar appearance] setBarTintColor:BG_Color];
    //设置导航条中的图片文字的颜色
    [[UINavigationBar appearance] setTintColor:RGBcolor(255, 255, 255)];
    NSDictionary* dict = @{
                           NSForegroundColorAttributeName: [UIColor whiteColor],
                           NSFontAttributeName: [UIFont systemFontOfSize:14.0]
                           };
    [[UINavigationBar appearance] setTitleTextAttributes:dict];
}

- (void)setTabBarTitle:(NSString *)title image:(NSString *)imageName selectedImage:(NSString *)selectImageName {
    self.title = title;
    self.tabBarItem.selectedImage = [UIImage imageNamed:selectImageName];
    self.tabBarItem.image = [UIImage imageNamed:imageName];
}
@end
