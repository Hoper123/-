//
//  RootTabBarController.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/24.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "RootTabBarController.h"
#import "RootNavigationController.h"

#import "HomeViewController.h"
#import "AppointmentViewController.h"
#import "QuickAppointViewController.h"
#import "MessageViewController.h"
#import "MeViewController.h"




@interface RootTabBarController ()

@end

@implementation RootTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
    
    [self initTabBarAppearance];
    [self initinitWithNavs];
}

//初始化TabBar
- (void)initTabBarAppearance {
    [[UITabBar appearance] setBackgroundColor:RGBcolor(255, 255, 255)];
    //[[UITabBar appearance] setBarTintColor:BG_Color];
    [[UITabBar appearance] setTintColor:BG_Color];

}

//初始化RootNavigationController
- (void)initinitWithNavs {
    //将Navigationcontroller加入到self.addChildViewController
    
    
    HomeViewController* homeVC = [[HomeViewController alloc] init];
    AppointmentViewController* appointVC = [[AppointmentViewController alloc] init];
    QuickAppointViewController* quickAppointVC = [[QuickAppointViewController alloc] init];
    MessageViewController* messageVC = [[MessageViewController alloc] init];
    MeViewController* meVC = [[MeViewController alloc] init];
    
    RootNavigationController* rootNav1 = [[RootNavigationController alloc] initWithRootViewController:homeVC];
    [rootNav1 setTabBarTitle:@"社区动态" image:@"tabbar_home" selectedImage:@"tabbar_home_selected"];
    [self addChildViewController:rootNav1];
    
    RootNavigationController* rootNav2 = [[RootNavigationController alloc] initWithRootViewController:appointVC];
    [rootNav2 setTabBarTitle:@"预约" image:@"tabbar_compose_background_icon_add" selectedImage:@"tabbar_compose_background_icon_add"];
    [self addChildViewController:rootNav2];
    
    RootNavigationController* rootNav3 = [[RootNavigationController alloc] initWithRootViewController:quickAppointVC];
    [rootNav3 setTabBarTitle:@"一键预约" image:@"tabbar_compose_button" selectedImage:@"main_badge"];
    [self addChildViewController:rootNav3];
    
    RootNavigationController* rootNav4 = [[RootNavigationController alloc] initWithRootViewController:messageVC];
    [rootNav4 setTabBarTitle:@"消息" image:@"tabbar_message_center" selectedImage:@"tabbar_message_center_selected"];
    [self addChildViewController:rootNav4];
    
    RootNavigationController* rootNav5 = [[RootNavigationController alloc] initWithRootViewController:meVC];
    [rootNav5 setTabBarTitle:@"我" image:@"tabbar_profile" selectedImage:@"tabbar_profile_selected"];
    [self addChildViewController:rootNav5];
    
}



@end
