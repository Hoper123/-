//
//  main.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/24.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
