//
//  AppDelegate.h
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/24.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RootTabBarController;
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic, strong) RootTabBarController* rootTabBar;


@end

