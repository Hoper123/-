//
//  UserDefaultsUtils.h
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/24.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserDefaultsUtils : NSObject

+(void)saveWithDic:(NSDictionary *)dic;

+(void)saveValue:(id) value forKey:(NSString *)key;

+(id)valueWithKey:(NSString *)key;

+(BOOL)boolValueWithKey:(NSString *)key;

+(void)saveBoolValue:(BOOL)value withKey:(NSString *)key;

+(void)removeValueWithKey:(NSString *)key;

+(void)removeValueWithArray:(NSArray *)arr;

+(void)removeAllValue;

+(void)print;
@end
