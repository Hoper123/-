//
//  UserDefaultsUtils.m
//  ZHSQ_iOS
//
//  Created by KFallen on 16/4/24.
//  Copyright © 2016年 zhsq. All rights reserved.
//

#import "UserDefaultsUtils.h"

#define DocumentsDirectory [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES) lastObject]
#define  UserDefaultsKey  @"userInfo"
@interface UserDefaultsUtils()
@property(nonatomic,strong)NSMutableDictionary *userInfoDic;
@end

@implementation UserDefaultsUtils
+(void)saveWithDic:(NSDictionary *)dic{
    NSArray * arrKeys=[dic allKeys];
    if (arrKeys.count>0) {
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSMutableDictionary *tempDic=[[NSMutableDictionary alloc] init];
        if([userDefaults objectForKey:UserDefaultsKey]){
            tempDic=[(NSMutableDictionary *)[userDefaults objectForKey:UserDefaultsKey] mutableCopy];
        }
        for (int i=0; i<arrKeys.count; i++) {
            [tempDic setValue:dic[arrKeys[i]] forKey:arrKeys[i]];
        }
        [userDefaults setObject:tempDic forKey:UserDefaultsKey];
        [userDefaults synchronize];
    }
}
+(void)saveValue:(id)value forKey:(NSString *)key{
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    NSMutableDictionary *dic=[[NSMutableDictionary alloc] init];
    if([userDefaults objectForKey:UserDefaultsKey]){
        dic=[(NSMutableDictionary *)[userDefaults objectForKey:UserDefaultsKey] mutableCopy];
    }
    [dic setObject:value forKey:key];
    [userDefaults setObject:dic forKey:UserDefaultsKey];
}
+(id)valueWithKey:(NSString *)key{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    return [(NSMutableDictionary *)[userDefaults objectForKey:UserDefaultsKey] objectForKey:key];
}
+(BOOL)boolValueWithKey:(NSString *)key{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    return [(NSNumber *)[(NSMutableDictionary *)[userDefaults objectForKey:UserDefaultsKey] objectForKey:key] boolValue];
}
+(void)saveBoolValue:(BOOL)value withKey:(NSString *)key{
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    NSMutableDictionary *tempDic=[[NSMutableDictionary alloc] init];
    if([userDefaults objectForKey:UserDefaultsKey]){
        tempDic=[(NSMutableDictionary *)[userDefaults objectForKey:UserDefaultsKey] mutableCopy];
    }
    [tempDic setObject:[NSNumber numberWithBool:value] forKey:key];
    [userDefaults setObject:tempDic forKey:UserDefaultsKey];
}
+(void)removeValueWithKey:(NSString *)key{
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    NSMutableDictionary *tempDic=[[NSMutableDictionary alloc] init];
    if([userDefaults objectForKey:UserDefaultsKey]){
        tempDic=[(NSMutableDictionary *)[userDefaults objectForKey:UserDefaultsKey]mutableCopy];
    }
    [tempDic removeObjectForKey:key];
    [userDefaults setObject:tempDic forKey:UserDefaultsKey];
}
+(void)removeValueWithArray:(NSArray *)arr
{
    if (arr&&arr.count>0) {
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSMutableDictionary *tempDic=[[NSMutableDictionary alloc] init];
        if([userDefaults objectForKey:UserDefaultsKey]){
            tempDic=[(NSMutableDictionary *)[userDefaults objectForKey:UserDefaultsKey]mutableCopy];
        }
        for (int i=0; i<arr.count; i++) {
            [tempDic removeObjectForKey:arr[i]];
        }
        [userDefaults setObject:tempDic forKey:UserDefaultsKey];
        [userDefaults synchronize];
    }
}
+(void)removeAllValue{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:UserDefaultsKey];
}
+(void)print{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSDictionary *dic = [userDefaults dictionaryRepresentation];
    NSLog(@"%@",dic);
}

@end
